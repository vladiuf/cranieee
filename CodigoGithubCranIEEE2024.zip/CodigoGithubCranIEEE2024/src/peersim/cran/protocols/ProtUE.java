package peersim.cran.protocols;

import java.util.ArrayList;
import java.util.List;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Node;
import peersim.cran.Constantes;
import peersim.cran.components.Times;
import peersim.cran.components.Utils;
import peersim.cran.msgs.Msg;
import peersim.cran.msgs.MsgEnd;
import peersim.cran.msgs.MsgLoop;
import peersim.cran.msgs.MsgRecoverBandwidth;
import peersim.cran.msgs.MsgReqPiece;
import peersim.cran.msgs.MsgSentPiece;
import peersim.cran.msgs.MsgStart;
import peersim.cran.transport.TransportContainer;
import peersim.edsim.EDProtocol;

public class ProtUE implements EDProtocol {
    
    private static final String PAR_TRANSPORT = "transport";
    private static final String PAR_PROT_RRH = "protocolrrh";
    private static final String PAR_PROT_COORD = "coord";

    public String prefix;
    public int transportid;
    public int coordid;
    public long idUE; // set at init -> CreateNw
    private int pid;
    private Node thisNode;
    public double bandwidthUsed;
    private TransportContainer ct; // set at init -> CreateNw
    public Node rrh;
    private int pidrrh;
    private int IDFILE;
    private Status[] piecesStatus;
    private Times[] piecesTime; // time each piece delay to be downloaded
    private long[] piecesRRH; // id of rrh from each piece was downloaded
    private Msg.WhoSend[] piecesWho; // from who each piece was downloaded (rrh/mec ou bbu)
    private int requests_in_flight = 0; // piece request still not returned.
    MsgLoop loopMsg = new MsgLoop();
    MsgEnd endMsg = new MsgEnd();
    private boolean seeder = false;

    private long timeInitLeech;
    private long timeEndLeech;


    public enum Status {
        NONE, REQUESTED, FAILED, DOWNLOADED;
    }

    public ProtUE(String prefix) {
        this.prefix = prefix;
        this.transportid = Configuration.getPid(prefix + "." + PAR_TRANSPORT);
        this.pidrrh = Configuration.getPid(prefix + "." + PAR_PROT_RRH);
        this.coordid = Configuration.getPid(prefix + "." + PAR_PROT_COORD);
    }

    public void init(long idUE, TransportContainer ct, Node rrh, int idFile, int amountPieces) {
        this.idUE = idUE;
        this.ct = ct;
        this.rrh = rrh;
        this.IDFILE = idFile;
        this.piecesStatus = new Status[amountPieces];
        this.piecesTime = new Times[amountPieces];
        this.piecesRRH = new long[amountPieces];
        this.piecesWho = new Msg.WhoSend[amountPieces];
    }

    @Override
    public void processEvent(Node thisNode, int pid, Object event) {
        this.pid = pid;
        this.thisNode = thisNode;

        if (event.getClass() == MsgStart.class) {
            println(event.getClass()+ " rrh:" + rrh.getID(), false);
            timeInitLeech = CommonState.getTime();
            //reqPieceToRRH();
            ct.send(500, loopMsg, thisNode, pid, TransportContainer.HowSend.RELIABLE);
        }

        if (event.getClass() == MsgLoop.class) {
            if (!seeder) reqPieceToRRH();
        }

        if (event.getClass() == MsgSentPiece.class) {
            MsgSentPiece msg = (MsgSentPiece)event;
            piecesStatus[msg.idPiece] = Status.DOWNLOADED;
            piecesTime[msg.idPiece].setEndTime(CommonState.getTime());
            piecesRRH[msg.idPiece] = msg.idrrh;
            piecesWho[msg.idPiece] = msg.who;
            println("MsgSentPiece: " + msg.idPiece, false);
        }

        if (event.getClass() == MsgRecoverBandwidth.class) {
            double bwBefore = bandwidthUsed;
            double sizePiece = Constantes.SIZE_PIECE;
            bandwidthUsed = bandwidthUsed - sizePiece;
            requests_in_flight--;
            println("MsgRecoverBandwidth before: " + bwBefore + " after: " + bandwidthUsed + " size: " + sizePiece, false);
        }

        if (event.getClass() == MsgEnd.class) {
            printAllInfo();
        }
    }
    
    private void reqPieceToRRH() {
        while (requests_in_flight <= Constantes.MAX_UE_PIECE_REQUEST) {
            int idPiece = getNextPieceToDownload();
            if (idPiece == -1) break;
            if (idPiece == -2) {
                println("ALL PIECES DOWNLOADED", false);
                timeEndLeech = CommonState.getTime();
                seeder = true;
                //ct.send(0, endMsg, thisNode, pid, TransportContainer.HowSend.RELIABLE);
                break;
            }
            println("piece requested: " + idPiece + " of file: " + IDFILE, false);
            
            long timeInit = CommonState.getTime();
            MsgReqPiece msg = new MsgReqPiece(thisNode, Msg.WhoSend.UE, IDFILE, idPiece, timeInit);
            piecesStatus[idPiece] = Status.REQUESTED;
            piecesTime[idPiece] = new Times(timeInit);
            long lat = 0;
            if (Constantes.USE_MOBILITY)
                lat = ct.getLatency(thisNode, rrh, pid, pidrrh, coordid);
            else
                lat = ct.getLatency(thisNode, rrh, pid, pidrrh, null);
            ct.send(lat, msg, rrh, pidrrh, TransportContainer.HowSend.RELIABLE);
            requests_in_flight++;
        }

        ct.send(Constantes.LOOP_UE_SEND_REQ_TO_RRH, loopMsg, thisNode, pid, TransportContainer.HowSend.RELIABLE);
    }

    /**
     * 
     * @return
     * idPiece to download.
     * -1 if there is no piece (they are requested or downloaded).
     * -2 if all pieces were downloaded.
     */
    private int getNextPieceToDownload() {
        int countdownloadedPieces = 0;
        for (int i = 0; i < piecesStatus.length; i++) {
            if (piecesStatus[i] == null || piecesStatus[i] == Status.NONE || piecesStatus[i] == Status.FAILED) {
                return i;
            }
            if (piecesStatus[i] == Status.DOWNLOADED) countdownloadedPieces++;
        }

        if (countdownloadedPieces == piecesStatus.length) return -2;
        return -1;
    }

    public Object clone() {
        println("clone", false);
        ProtUE ue = new ProtUE(prefix);
        return ue;
    }

    public int getPiecesDownloaded() {
        int piecesDownloaded = 0;
        for (int i = 0; i < piecesStatus.length; i++) {
            if (piecesStatus[i] == Status.DOWNLOADED) piecesDownloaded++;
        }
        return piecesDownloaded;
    }

    /**
     * 0 only my rrh. 1 only other rrh. 2 from both (my and other).
     * @return
     */
    public int whereDownloadedRRH() {
        boolean my = false;
        boolean ot = false;
        for (int i = 0; i < piecesRRH.length; i++) {
            if (piecesRRH[i] == rrh.getID()) my = true;
            if (piecesRRH[i] != rrh.getID()) ot = true;
        }

        if (my && ot) return 2;
        if (ot) return 1;
        
        return 0;
    }

    /**
     * [0] = general average. [1] my rrh.mec average or -1 or NAN. [2] other rrh average or -1 or NAN.
     * [3] my rrh.bbu average
     * @param piecesDownloaded
     * @return
     */
    public Double[] averagePiecesDelayInSeconds(int piecesDownloaded) {

        Double[] avgs = new Double[4];
        avgs[0] = -1.0; avgs[1] = -1.0; avgs[2] = -1.0; avgs[3] = -1.0;

        long totalPiecesDelay = 0;
        long totalPiecesDelayMy_MEC = 0;
        long totalPiecesDelayMy_BBU = 0;
        long totalPiecesDelayOther = 0;

        int piecesDownloadedMy_MEC = 0;
        int piecesDownloadedMy_BBU = 0;
        
        for (int i = 0; i < piecesStatus.length; i++) {
            boolean isMyRRH = piecesRRH[i] == rrh.getID() ? true : false;
            boolean isBBU = piecesWho[i] == Msg.WhoSend.BBU ? true : false;
            if (piecesStatus[i] == Status.DOWNLOADED) {
                totalPiecesDelay += piecesTime[i].delay();
                if (isMyRRH) {
                    if (isBBU) {
                        totalPiecesDelayMy_BBU += piecesTime[i].delay();
                        piecesDownloadedMy_BBU ++;
                    } else {
                        totalPiecesDelayMy_MEC += piecesTime[i].delay();
                        piecesDownloadedMy_MEC ++;
                    }
                } else totalPiecesDelayOther += piecesTime[i].delay();
            }
        }

        avgs[0] = Utils.timeSimulationInSeconds(totalPiecesDelay) / (piecesDownloaded + 0.0); // in seconds
        avgs[1] = Utils.timeSimulationInSeconds(totalPiecesDelayMy_MEC) / (piecesDownloadedMy_MEC + 0.0); // in seconds
        avgs[2] = Utils.timeSimulationInSeconds(totalPiecesDelayOther) / (piecesDownloaded - (piecesDownloadedMy_MEC + piecesDownloadedMy_BBU) + 0.0); // in seconds
        avgs[3] = Utils.timeSimulationInSeconds(totalPiecesDelayMy_BBU) / (piecesDownloadedMy_BBU + 0.0); // in seconds

        return avgs;
    }

    public void printAllInfo() {
        double timeLeeching = Utils.timeSimulationInSeconds(timeEndLeech - timeInitLeech); // in seconds
        int totalRRHForwarded = 0;
        long totalPiecesDelay = 0;
        long timeLeechingOtherRRH = 0;
        long timeLeechingMyRRH = 0;

        int PIECES_DOWNLOADED = 0;
        for (int i = 0; i < piecesStatus.length; i++) {
            if (piecesStatus[i] != Status.DOWNLOADED) continue;
            
            PIECES_DOWNLOADED++;
            totalPiecesDelay += piecesTime[i].delay();
            if (piecesRRH[i] != rrh.getID()) { // it is not my rrh, was redirected
                totalRRHForwarded ++;
                timeLeechingOtherRRH += piecesTime[i].delay();
            } else { // it is my rrh
                timeLeechingMyRRH += piecesTime[i].delay();
            }
        }

        if (PIECES_DOWNLOADED == 0) {
            println("DONT downloaded ANYTHING OF FILE:" + IDFILE, true);
            return;
        }
        
        double percentRedirs = (totalRRHForwarded + 0.0) / (piecesRRH.length + 0.0);

        double avgPieceDelay = Utils.timeSimulationInSeconds(totalPiecesDelay) / (PIECES_DOWNLOADED + 0.0); // in seconds
        

        Double[] ODvalues = calculateOperationalDownloads(PIECES_DOWNLOADED);

        double theoreticalPieceDelaySec = (Constantes.SIZE_PIECE) / Constantes.CAPACITY_RRH2UE;
        double theoreticalTotalDelaySec = (Constantes.SIZE_PIECE * PIECES_DOWNLOADED) / Constantes.CAPACITY_RRH2UE;
        double linkConsuptionProportion = ODvalues[0] / Constantes.CAPACITY_UE;

        String str =    "downloaded pieces of file: " + IDFILE + " -- Downloaded: " + PIECES_DOWNLOADED + " of total: " + piecesTime.length + "\n" +
                        "\t TimeLeechingSec: " + timeLeeching + " " + (timeEndLeech-timeInitLeech) + " [init: " + timeInitLeech + " end: " + timeEndLeech + "] \n" +
                        "\t TimeLeechingSecMyRRH: " + Utils.timeSimulationInSeconds(timeLeechingMyRRH) + " TimeLeechingSecOtherRRH: "  + Utils.timeSimulationInSeconds(timeLeechingOtherRRH) + "\n" +
                        "\t AvgPieceDelaySec: " + Utils.TwoDec(avgPieceDelay) + " [totalDelaySec: " + Utils.timeSimulationInSeconds(totalPiecesDelay) + "] \n" +
                        "\t TheoreticalTotalPieceDelaySec: " +theoreticalPieceDelaySec + " [totalDelaySec: " + theoreticalTotalDelaySec + "] \n" +
                        "\t OperDownloadKbps: " + Utils.TwoDec(ODvalues[0]) + " " + 
                            "\t OperDown.myRRH_MEC: " + Utils.TwoDec(ODvalues[1]) + " " +
                            "\t OperDown.myRRH_BBU: " + Utils.TwoDec(ODvalues[3]) + " " +
                            "\t OperDown.otherRRH: " + Utils.TwoDec(ODvalues[2]) + "\n" +
                        "\t Redirections: " + totalRRHForwarded + " of: " + PIECES_DOWNLOADED + " (" + Utils.TwoDec(percentRedirs*100) + "%) \n" +
                        "\t LinkConsuption: " + Utils.TwoDec(linkConsuptionProportion*100) + " %" + "\n" +
                        "\t CapacityUEKbps: " + Utils.TwoDec(Constantes.CAPACITY_UE) + " CapacityUERRH: " + Utils.TwoDec(Constantes.CAPACITY_RRH2UE);
        println(str, true);
    }

    /**
     * [0] OperDownload in Kbps or -1 if none.
     * [1] OperDown.myRRH.myMEC in Kbps or -1 if none.
     * [2] OperDown.otherRRH in Kbps or -1 if none.
     * [3] OperDown.myRRH.BBU in Kbps or -1 if none.
     * @return
     */
    public Double[] calculateOperationalDownloads(int piecesDownloaded) {
        int QTY_VARS = 4;
        List<Double[]> partialods = new ArrayList<>();
        Double[] ods = new Double[QTY_VARS];
        ods[0] = -1.0; ods[1] = -1.0; ods[2] = -1.0; ods[3] = -1.0;

        int iterations = piecesDownloaded / Constantes.MAX_UE_PIECE_REQUEST;
        if (iterations == 0) iterations = 1;

        int currentIdx = 0;
        for (int i = 0; i < iterations; i++) {

            ods = new Double[QTY_VARS];
            ods[0] = -1.0; ods[1] = -1.0; ods[2] = -1.0; ods[3] = -1.0;
            
            Long initTime = null;
            Long initTimeMyRRH_MEC = null;
            Long initTimeMyRRH_BBU = null;
            Long initTimeOtherRRH = null;
            long endTime = -1;
            long endTimeMyRRH_MEC = -1;
            long endTimeMyRRH_BBU = -1;
            long endTimeOtherRRH = -1;

            int countDownloadedMyRRH_MEC = 0;
            int countDownloadedMyRRH_BBU = 0;
            int countDownloadedOtherRRH = 0;

            int piece = 0;
            while (piece < Constantes.MAX_UE_PIECE_REQUEST) {
                if (piecesStatus[currentIdx] == Status.DOWNLOADED) {
                    boolean isMyRRH = piecesRRH[currentIdx] == rrh.getID() ? true : false;
                    boolean isBBU = piecesWho[currentIdx] == Msg.WhoSend.BBU ? true : false;
                    Times times = piecesTime[currentIdx];
                    if (initTime == null) initTime = times.initTime;
                    if (initTimeMyRRH_BBU == null && isMyRRH && isBBU) initTimeMyRRH_BBU = times.initTime;
                    if (initTimeMyRRH_MEC == null && isMyRRH && ! isBBU) initTimeMyRRH_MEC = times.initTime;
                    else if (initTimeOtherRRH == null && !isMyRRH) initTimeOtherRRH = times.initTime;
                    
                    endTime = times.endTime;
                    if (isMyRRH) {
                        if (isBBU) {
                            endTimeMyRRH_BBU = times.endTime;
                            countDownloadedMyRRH_BBU++;
                        } else {
                            endTimeMyRRH_MEC = times.endTime;
                            countDownloadedMyRRH_MEC++;
                        }
                    }
                    else {
                        endTimeOtherRRH = times.endTime;
                        countDownloadedOtherRRH++;
                    }
                }
                piece++;
                currentIdx++;
                
            }

            /*println("currentidx: " + currentIdx, true);
            println("my: " + countDownloadedMyRRH + " oth: " + countDownloadedOtherRRH + " init: " + initTime + " end: " + endTime, true);
            println("secs: " + Utils.timeSimulationInSeconds(endTime - initTime), true);
            println("mult: " + ((countDownloadedMyRRH + countDownloadedOtherRRH)*Constantes.SIZE_PIECE), true); */
            ods[0] = (countDownloadedMyRRH_MEC + countDownloadedOtherRRH + countDownloadedMyRRH_BBU + 0.0) * Constantes.SIZE_PIECE / Utils.timeSimulationInSeconds(endTime-initTime);
            if (ods[0] > Constantes.CAPACITY_UE) ods[0] = Constantes.CAPACITY_UE;

            if (endTimeMyRRH_MEC != -1) {
                ods[1] = (countDownloadedMyRRH_MEC) * Constantes.SIZE_PIECE / Utils.timeSimulationInSeconds(endTimeMyRRH_MEC-initTimeMyRRH_MEC);
                if (ods[1] > Constantes.CAPACITY_UE) ods[1] = Constantes.CAPACITY_UE;
            }
            if (endTimeOtherRRH != -1) {
                ods[2] = (countDownloadedOtherRRH) * Constantes.SIZE_PIECE / Utils.timeSimulationInSeconds(endTimeOtherRRH-initTimeOtherRRH);
                if (ods[2] > Constantes.CAPACITY_UE) ods[2] = Constantes.CAPACITY_UE;
            }
            if (endTimeMyRRH_BBU != -1) {
                ods[3] = (countDownloadedMyRRH_BBU) * Constantes.SIZE_PIECE / Utils.timeSimulationInSeconds(endTimeMyRRH_BBU-initTimeMyRRH_BBU);
                if (ods[3] > Constantes.CAPACITY_UE) ods[3] = Constantes.CAPACITY_UE;
            }

            partialods.add(ods);
        }

        int countPartial = 0, countPartialMyMEC = 0, countPartialOther = 0, countPartialMyBBU = 0;
        int sumPartial = 0, sumPartialMyMEC = 0, sumPartialOther = 0, sumPartialMyBBU = 0;
        for (Double[] partial : partialods) {
            if (partial[0] != -1.0) {
                sumPartial += partial[0];
                countPartial++;
            }
            if (partial[1] != -1.0) {
                sumPartialMyMEC += partial[1];
                countPartialMyMEC++;
            }
            if (partial[2] != -1.0) {
                sumPartialOther += partial[2];
                countPartialOther++;
            }
            if (partial[3] != -1.0) {
                sumPartialMyBBU += partial[3];
                countPartialMyBBU++;
            }
        }

        ods = new Double[QTY_VARS];
        ods[0] = sumPartial / (countPartial+0.0);
        ods[1] = sumPartialMyMEC / (countPartialMyMEC+0.0);
        ods[2] = sumPartialOther / (countPartialOther+0.0);
        ods[3] = sumPartialMyBBU / (countPartialMyBBU+0.0);

        return ods;
    }

    /* */
    public boolean isSeeder() {
        return seeder;
    }

    private void println(String str, boolean print) {
        if (print) System.out.println("[ProtUE] (" + idUE + ") " + str + " -- " + CommonState.getTime());
    }
}
