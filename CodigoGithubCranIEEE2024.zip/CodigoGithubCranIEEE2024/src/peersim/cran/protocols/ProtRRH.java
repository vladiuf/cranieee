package peersim.cran.protocols;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Network;
import peersim.core.Node;
import peersim.cran.Constantes;
import peersim.cran.components.MEC;
import peersim.cran.components.NodeContainer;
import peersim.cran.components.Utils;
import peersim.cran.msgs.*;
import peersim.cran.transport.TransportContainer;
import peersim.edsim.EDProtocol;

import java.util.*;

public class ProtRRH implements EDProtocol {
    
    private static final String PAR_TRANSPORT = "transport";
    private static final String PAR_PROT_UE = "protocolue";
    private static final String PAR_PROT_BBU = "protocolbbu";


    public String prefix;
    public int transportid;
    public long idRRH; // set at init -> CreateNw
    private int pid;
    private int pidue;
    private Node thisNode;
    private Node bbu;
    private int pidbbu;
    public int idRouter;
    private TransportContainer ct; // set at init -> CreateNw
    MsgLoop loopMsg = new MsgLoop();

    
    private List<MsgReqPiece> queuePiece = new ArrayList<>();
    //                idUE  bandwidth
    private Hashtable<Long, Double> bandwidthUE = new Hashtable<>();
    public double bandwidthUsed;
    private MEC mec = new MEC();
    
    //              idFile          
    private HashSet<Integer> filesRequested = new HashSet<>(); // requested by me to BBU or RRHs
    private List<MsgReqFile> queueFileToRRH = new ArrayList<>(); // requested to me for sending to RRH.
    //               idMsg  received
    private Hashtable<Long, Boolean> msgsRequested = new Hashtable<>(); // requested by me to BBU
    

    public ProtRRH(String prefix) {
        this.prefix = prefix;
        this.transportid = Configuration.getPid(prefix + "." + PAR_TRANSPORT);
        this.pidue = Configuration.getPid(prefix + "." + PAR_PROT_UE);
        this.pidbbu = Configuration.getPid(prefix + "." + PAR_PROT_BBU);
    }

    public void init(long idRRH, Node bbu, TransportContainer ct, int idRouter) {
        this.idRRH = idRRH;
        this.bbu = bbu;
        this.ct = ct;
        this.idRouter = idRouter;
    }

    @Override
    public void processEvent(Node thisNode, int pid, Object event) {
    
        this.pid = pid;
        this.thisNode = thisNode;

        if (event.getClass() == MsgStart.class) {
            MsgStart start = (MsgStart)event;
            init(start.id, start.node, start.tc, start.idrouter);
            //println("MsgStart", true);
            println("MsgStart idRouter: " + idRouter, true);
            sendPieceToUE();
        }
        if (event.getClass() == MsgLoop.class) {
            sendPieceToUE();
            sendFileToOtherRRH();
        }

        if (event.getClass() == MsgReqPiece.class) { // coming from UE
            MsgReqPiece msg = (MsgReqPiece)event;

            queuePiece.add(msg);
            println("piece added to queue(" + queuePiece.size() + ") Piece:" +  msg.idPiece + " from: " + msg.src.getID(), false);

            /*
            int idFile = msg.idFile;
            if (mec.myHasStoredFile(idFile)) {
                println("I already have the file: " + idFile + " for piece: " + msg.idPiece, false);
            } else if (mec.otherHasStoredFile(idFile)) {
                requestFileToOtherMEC(idFile);
            } else {
                requestFileToBBU(idFile); // request to CN via BBU
            }*/
        } 

        if (event.getClass() == MsgSentPiece.class) { // coming from bbu
            MsgSentPiece msg = (MsgSentPiece)event;
            msgsRequested.put(msg.idMsgReq, true);
        }

        if (event.getClass() == MsgSentFile.class) { // coming from bbu
            MsgSentFile msg = (MsgSentFile)event;
            mec.myStoreFile(msg.idFile);
            filesRequested.remove(msg.idFile);

            // signal other MECs (located in their respectives RRHs).
            List<Long> indexes_rrhs = Constantes.IDS_RRHs;
            MsgHasFile msgHasFile = new MsgHasFile(msg.idFile, idRRH);
            for (long idremoterrh : indexes_rrhs) {
                if (idremoterrh == idRRH) continue; // dont send to myself
                Node rrh = Network.get((int)idremoterrh);
                long delay = ct.getLatency(thisNode, rrh, pid, pid);
                ct.send(delay, msgHasFile, rrh, pid, TransportContainer.HowSend.RELIABLE);    
            }
        }

        if (event.getClass() == MsgReqFile.class) { // coming from another rrh (is not used)
            MsgReqFile msg = (MsgReqFile)event;
            NodeContainer container = msg.getLastIntermediary();
            println("File requested: " + msg.idFile + " from rrh: " + container.node.getID(), true);
            queueFileToRRH.add(msg);
        }

        if (event.getClass() == MsgHasFile.class) { // coming from MEC' RRH
            MsgHasFile msg = (MsgHasFile)event;
            mec.otherStoreFile(msg.idfile, msg.rrhHasFile);
        }

        if (event.getClass() == MsgRecoverBandwidth.class) {
            MsgRecoverBandwidth msg = (MsgRecoverBandwidth)event;
            double size = msg.size;

            double bwBefore = bandwidthUsed;
            bandwidthUsed = bandwidthUsed - size; // wherever piece or file size
            if (msg.what == MsgRecoverBandwidth.What.PIECE) {
                Double bwConsumed = bandwidthUE.get(msg.idSrc);
                bandwidthUE.put(msg.idSrc, bwConsumed - size);
            }

            println("MsgRecoverBandwidth before: " + bwBefore + " after: " + bandwidthUsed + " size: " + size, false);
        }        
    }

    private void sendPieceToUE() {

        ListIterator<MsgReqPiece> iter = queuePiece.listIterator();
        while(iter.hasNext()){ // TODO com window para permitir outros
            MsgReqPiece msg = iter.next();
            //if (! mec.myHasStoredFile(msg.idFile)) continue; // I dont have the file, so I cant send it.
            int idFile = msg.idFile;
            if (! mec.myHasStoredFile(idFile)) {
                if (mec.hasSpaceToStore(idFile)) {
                    requestFileToBBU(idFile);
                    continue;
                } else {   
                    if (mec.otherHasStoredFile(idFile)) {
                        // forward msg to rrh if there is one
                        Set<Long> otherMECs = mec.getOthersHasFile(idFile);
                        Node nearRRH = ct.getNearestRRH(idRRH, otherMECs, pid);
                        long lat = ct.getLatency(thisNode, nearRRH, pid, pid);
                        ct.send(lat, msg, nearRRH, pid, TransportContainer.HowSend.RELIABLE);            
                        iter.remove();
                        continue;
                    } else {
                        requestPieceToBBU(msg);
                        //continue;
                    }
                }
            }
            
            boolean myStore = mec.myHasStoredFile(idFile);
            boolean bbuSent = isBBUSentPiece(msg);

            if (myStore || bbuSent) { // my mec has the file OR the BBU send to me the piece
                // send to UE
                ProtUE ue = (ProtUE) msg.src.getProtocol(pidue); // src eh classe Node
                Double bwUsedUERRH = bandwidthUE.getOrDefault(ue.idUE, 0.0);
                double sizePiece = Constantes.SIZE_PIECE;

                if (waitingFile()) break; // there is a file to be downloaded
                if (bandwidthUsed + sizePiece > Constantes.CAPACITY_RRH) break; // there is no capacity in the rrh
                if (ue.bandwidthUsed + sizePiece > Constantes.CAPACITY_UE) continue;  // there is no capacity in the ue
                if (bwUsedUERRH + sizePiece > Constantes.CAPACITY_RRH2UE) continue; // there is no capacity in the rrh-ue channel

                bandwidthUsed = bandwidthUsed + sizePiece;
                ue.bandwidthUsed = ue.bandwidthUsed + sizePiece;
                bandwidthUE.put(ue.idUE, bwUsedUERRH + sizePiece);
                
                println("sending piece: " + msg.idPiece + " to: " + msg.src.getID(), false);
                MsgSentPiece pieceMsg;
                
                if (bbuSent)
                    pieceMsg = new MsgSentPiece(msg.idMsg, thisNode, Msg.WhoSend.BBU, msg.idFile, msg.idPiece, idRRH, CommonState.getTime());
                else 
                    pieceMsg = new MsgSentPiece(msg.idMsg, thisNode, Msg.WhoSend.RRH, msg.idFile, msg.idPiece, idRRH, CommonState.getTime());

                long lat = ct.getLatency(thisNode, msg.src, pid, pidue);
                double tra = ct.getTransmissionDelay(Constantes.SIZE_PIECE, Constantes.CAPACITY_RRH2UE);
                long delay = lat + (long)tra;

                println(lat + " " + tra, false);
                ct.send(delay, pieceMsg, msg.src, pidue, TransportContainer.HowSend.RELIABLE);

                MsgRecoverBandwidth bwMsg = new MsgRecoverBandwidth(ue.idUE, Constantes.SIZE_PIECE, MsgRecoverBandwidth.What.PIECE);
                ct.send(delay, bwMsg, thisNode, pid, TransportContainer.HowSend.RELIABLE);
                ct.send(delay, bwMsg, msg.src, pidue, TransportContainer.HowSend.RELIABLE);

                iter.remove();
                BBURemovePiece(msg);
            } else { // just wait
                continue;
            }
            
        }
        //println("queue size: " + queuePiece.size());

        ct.send(Constantes.LOOP_RRH_SEND_PIECE_TO_UE, loopMsg, thisNode, pid, TransportContainer.HowSend.RELIABLE);
    }

    public void sendFileToOtherRRH() {

        if (queueFileToRRH.isEmpty()) return;

        // sending just one (because I - RRH- need to prioritize my UEs)
        // similar code as ProtBBU.sendFileToRRH
        ListIterator<MsgReqFile> iter = queueFileToRRH.listIterator();
        MsgReqFile msg = iter.next();
        NodeContainer container = msg.getLastIntermediary();
        
        // From BBU point of view, there is just one RRH to send (just one intermediary)
        ProtRRH rrh = (ProtRRH) container.node.getProtocol(pid);
        double fileSize = Constantes.FILE_SIZE;
        String strPrint = "me rrh used: " + bandwidthUsed + " estimated: " + (bandwidthUsed + fileSize) + " cap: " + Constantes.CAPACITY_RRH + "\n" +
                "\t      other rrh used: " + rrh.bandwidthUsed + " estimated: " + (rrh.bandwidthUsed + fileSize) + " cap: " + Constantes.CAPACITY_RRH + "\n";
        if (bandwidthUsed + fileSize > Constantes.CAPACITY_BBU) return; // there is no capacity in here
        if (rrh.bandwidthUsed + fileSize > Constantes.CAPACITY_RRH) return; // there is no capacity in the other rrh

        bandwidthUsed = bandwidthUsed + fileSize;
        rrh.bandwidthUsed = rrh.bandwidthUsed + fileSize;
        
        long lat = ct.getLatency(thisNode, container.node, pid, pid);
        double tra = ct.getTransmissionDelay(fileSize, Constantes.CAPACITY_RRH);
        long delay = lat + (long)tra;
        println(strPrint +
            "\t      rrh sending file: " + msg.idFile + " to other rrh: " + container.node.getID() + " lat/transm: " + lat + "/" + Utils.TwoDec(tra), true);

        MsgSentFile msgFile = new MsgSentFile(msg.idFile);
        ct.send(delay, msgFile, container.node, pid, TransportContainer.HowSend.RELIABLE);

        MsgRecoverBandwidth bwMsg = new MsgRecoverBandwidth(idRRH, fileSize, MsgRecoverBandwidth.What.FILE);
        ct.send(delay, bwMsg, thisNode, pid, TransportContainer.HowSend.RELIABLE);
        ct.send(delay, bwMsg, container.node, pid, TransportContainer.HowSend.RELIABLE);

        msg.removeIntermediary(rrh.idRRH);
        iter.remove();
    }

    private boolean waitingFile() { 
        
        if (filesRequested.isEmpty() && queueFileToRRH.isEmpty()) return false;

        // here, there is or a file requested by me or to send to other rrh
        if (bandwidthUsed + Constantes.FILE_SIZE + Constantes.SIZE_PIECE > Constantes.CAPACITY_RRH) {
            // letting bandwidth space to receive the file requested or send to other rrh
            return true;
        }
        return false;
    }

    private void requestFileTo(int idFile, Node toNode, int pidToNode) {
        if (filesRequested.contains(idFile)) return; // file already requested
        filesRequested.add(idFile);
        println("requestFile: " + idFile + " to: " + toNode.getID(), true);
        MsgReqFile msg = new MsgReqFile(null, null, idFile, CommonState.getTime());
        msg.addIntermediary(new NodeContainer(Msg.WhoSend.RRH, thisNode));
        long lat = ct.getLatency(thisNode, toNode, pid, pidToNode);
        ct.send(lat, msg, toNode, pidToNode, TransportContainer.HowSend.RELIABLE);
    }

    private void requestFileToBBU(int idFile) {
        requestFileTo(idFile, bbu, pidbbu);
    }

    private void requestFileToOtherMEC(int idFile) {
        
        Set<Long> otherMECs = mec.getOthersHasFile(idFile);
        Node nearRRH = ct.getNearestRRH(idRRH, otherMECs, pid);
        requestFileTo(idFile, nearRRH, pid);
    }

    private void requestPieceToBBU(MsgReqPiece msg) {
        if (msgsRequested.containsKey(msg.idMsg)) return; // msg already processed
        msgsRequested.put(msg.idMsg, false);

        println("requestPiece: " + msg.idMsg + " to BBU", false);
        msg.addIntermediary(new NodeContainer(Msg.WhoSend.RRH, thisNode));
        long lat = ct.getLatency(thisNode, bbu, pid, pidbbu);
        ct.send(lat, msg, bbu, pidbbu, TransportContainer.HowSend.RELIABLE);
    }

    private boolean isBBUSentPiece(MsgReqPiece msg) {
        return msgsRequested.getOrDefault(msg.idMsg, false);
    }

    private void BBURemovePiece(MsgReqPiece msg) {
        msgsRequested.remove(msg.idMsg);
    }

    public Object clone() {
        println("clone", false);
        ProtRRH rrh = new ProtRRH(prefix);
        return rrh;
    }

    private void println(String str, boolean print) {
        if(print) System.out.println("[ProtRRH] (" + idRRH + ") " + str + " -- " + CommonState.getTime());
    }

}
