package peersim.cran.protocols;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;
import java.util.HashSet;
import java.util.Hashtable;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Node;
import peersim.cran.Constantes;
import peersim.cran.components.NodeContainer;
import peersim.cran.components.Utils;
import peersim.cran.msgs.Msg;
import peersim.cran.msgs.MsgLoop;
import peersim.cran.msgs.MsgRecoverBandwidth;
import peersim.cran.msgs.MsgReqFile;
import peersim.cran.msgs.MsgReqPiece;
import peersim.cran.msgs.MsgSentFile;
import peersim.cran.msgs.MsgSentPiece;
import peersim.cran.msgs.MsgStart;
import peersim.cran.transport.TransportContainer;
import peersim.edsim.EDProtocol;

public class ProtBBU implements EDProtocol {

    private static final String PAR_TRANSPORT = "transport";
    private static final String PAR_PROT_RRH = "protocolrrh";


    public String prefix;
    public int transportid;
    public long idBBU; // set at init -> CreateNw
    private int pid;
    private Node thisNode;
    public double bandwidthUsed;
    private TransportContainer ct; // set at init -> CreateNw
    MsgLoop loopMsg = new MsgLoop();
    private int pidrrh;
    private long TOTAL_DELAY_TO_CN;


    private List<MsgReqFile> queueFileToRRH = new ArrayList<>();
    private List<MsgReqPiece> queuePieceToRRH = new ArrayList<>();

    private Hashtable<Long, HashSet<Integer>> piecesSentTest = new Hashtable<>();

    public ProtBBU(String prefix) {
        this.prefix = prefix;
        this.transportid = Configuration.getPid(prefix + "." + PAR_TRANSPORT);
        this.pidrrh = Configuration.getPid(prefix + "." + PAR_PROT_RRH);
    }

    public void init(long idBBU, TransportContainer ct) {
        this.idBBU = idBBU;
        this.ct = ct;
        println("init", true);
    }

    @Override
    public void processEvent(Node thisNode, int pid, Object event) {
        this.pid = pid;
        this.thisNode = thisNode;

        if (event.getClass() == MsgStart.class) {
            MsgStart start = (MsgStart)event;
            init(start.id, start.tc);
            println("MsgStart", true);
            TOTAL_DELAY_TO_CN = Constantes.LATENCY_BBU_CN + (long)(ct.getTransmissionDelay(Constantes.FILE_SIZE, Constantes.CAPACITY_BBU));
            sendFileToRRH();
            sendPieceToRRH();
        }

        if (event.getClass() == MsgLoop.class) {
            sendFileToRRH();
            sendPieceToRRH();
        }

        if (event.getClass() == MsgReqFile.class) { // coming from RRH
            MsgReqFile msg = (MsgReqFile)event;
            NodeContainer container = msg.getLastIntermediary();
            println("File requested: " + msg.idFile + " from rrh: " + container.node.getID(), true);
            queueFileToRRH.add(msg);
            //sendFileToRRH();
        }

        if (event.getClass() == MsgReqPiece.class) { // coming from RRH
            MsgReqPiece msg = (MsgReqPiece)event;
            queuePieceToRRH.add(msg);

            HashSet<Integer> set = piecesSentTest.getOrDefault(msg.src.getID(), new HashSet<>());
            if (set.contains(msg.idPiece)) {
                System.out.println("ERRO PIECE REQUESTED JA ENVIADA ANTES: [" + msg.idFile + " -- " + msg.idPiece + "] " + msg.idMsg + " / " + msg.src.getID());
                System.exit(0);
            }

            set.add(msg.idPiece);
            piecesSentTest.put(msg.src.getID(), set);
        }
        

        if (event.getClass() == MsgRecoverBandwidth.class) {
            MsgRecoverBandwidth msg = (MsgRecoverBandwidth)event;
            double size = msg.size;

            double bwBefore = bandwidthUsed;
            bandwidthUsed = bandwidthUsed - size;

            println("MsgRecoverBandwidth before: " + bwBefore + " after: " + bandwidthUsed + " size: " + size, false);
        }      
    }

    public void sendFileToRRH() {
        ListIterator<MsgReqFile> iter = queueFileToRRH.listIterator();
        
        while(iter.hasNext()){ // TODO com window para permitir outros
            MsgReqFile msg = iter.next();

            NodeContainer container = msg.getLastIntermediary();
            
            // From BBU point of view, there is just one RRH to send (just one intermediary)
            ProtRRH rrh = (ProtRRH) container.node.getProtocol(pidrrh);

            MsgSentFile msgFile = new MsgSentFile(msg.idFile);
            boolean sent = sendPacketToRRH(Constantes.FILE_SIZE, container, msgFile, true);

            /*
            double fileSize = Constantes.FILE_SIZE;
            String strPrint = "me used: " + bandwidthUsed + " estimated: " + (bandwidthUsed + fileSize) + " cap: " + Constantes.CAPACITY_BBU + "\n" +
                    "\t      rrh used: " + rrh.bandwidthUsed + " estimated: " + (rrh.bandwidthUsed + fileSize) + " cap: " + Constantes.CAPACITY_RRH + "\n";
            if (bandwidthUsed + fileSize > Constantes.CAPACITY_BBU) break; // there is no capacity in the bbu
            if (rrh.bandwidthUsed + fileSize > Constantes.CAPACITY_RRH) continue; // there is no capacity in the rrh

            bandwidthUsed = bandwidthUsed + fileSize;
            rrh.bandwidthUsed = rrh.bandwidthUsed + fileSize;
            
            long lat = ct.getLatency(thisNode, container.node, pid, pidrrh);
            double minCapacity = Math.min(Constantes.CAPACITY_RRH, Constantes.CAPACITY_BBU);
            double tra = ct.getTransmissionDelay(fileSize, minCapacity);
            long delay = TOTAL_DELAY_TO_CN + lat + (long)tra; // add delay as downloaded from CN
            println(strPrint + 
                    "\t      bbu sending file: " + msg.idFile + " to: " + container.node.getID() + " lat/transm: " + lat + "/" + Utils.TwoDec(tra), true);

            MsgSentFile msgFile = new MsgSentFile(msg.idFile);
            ct.send(delay, msgFile, container.node, pidrrh, TransportContainer.HowSend.RELIABLE);

            MsgRecoverBandwidth bwMsg = new MsgRecoverBandwidth(idBBU, fileSize, MsgRecoverBandwidth.What.FILE);
            ct.send(delay, bwMsg, thisNode, pid, TransportContainer.HowSend.RELIABLE);
            ct.send(delay, bwMsg, container.node, pidrrh, TransportContainer.HowSend.RELIABLE);
            */
            if (sent) {
                msg.removeIntermediary(rrh.idRRH);
                iter.remove();
            }
        }

        ct.send(Constantes.LOOP_BBU_SEND_FILE_TO_RRH, loopMsg, thisNode, pid, TransportContainer.HowSend.RELIABLE);
    }

    public void sendPieceToRRH() {
        ListIterator<MsgReqPiece> iter = queuePieceToRRH.listIterator();
        
        while(iter.hasNext()){ // TODO com window para permitir outros
            MsgReqPiece msg = iter.next();

            NodeContainer container = msg.getLastIntermediary();
            
            // From BBU point of view, there is just one RRH to send (just one intermediary)
            ProtRRH rrh = (ProtRRH) container.node.getProtocol(pidrrh);

            MsgSentPiece msgFile = new MsgSentPiece(msg.idMsg, thisNode, Msg.WhoSend.BBU, msg.idFile, msg.idPiece, rrh.idRRH, CommonState.getTime());
            boolean sent = sendPacketToRRH(Constantes.SIZE_PIECE, container, msgFile, false);

            if (sent) {
                println("bbu Piece sent: [" + msg.idFile + " -- " + msg.idPiece + "] " + msg.idMsg  + " / " + msg.src.getID(), false);
                msg.removeIntermediary(rrh.idRRH);
                iter.remove();
            }
        }
    }


    public boolean sendPacketToRRH(double packetSize, NodeContainer container, Msg msgSent, boolean isFile) {
            
        // From BBU point of view, there is just one RRH to send (just one intermediary)
        ProtRRH rrh = (ProtRRH) container.node.getProtocol(pidrrh);

        double fileSize = packetSize;
        String strPrint = "me used: " + bandwidthUsed + " estimated: " + (bandwidthUsed + fileSize) + " cap: " + Constantes.CAPACITY_BBU + "\n" +
                "\t      rrh used: " + rrh.bandwidthUsed + " estimated: " + (rrh.bandwidthUsed + fileSize) + " cap: " + Constantes.CAPACITY_RRH + "\n";
        if (bandwidthUsed + fileSize > Constantes.CAPACITY_BBU) return false; // there is no capacity in the bbu
        if (rrh.bandwidthUsed + fileSize > Constantes.CAPACITY_RRH) return false; // there is no capacity in the rrh

        bandwidthUsed = bandwidthUsed + fileSize;
        rrh.bandwidthUsed = rrh.bandwidthUsed + fileSize;
        
        long lat = ct.getLatency(thisNode, container.node, pid, pidrrh);
        double minCapacity = Math.min(Constantes.CAPACITY_RRH, Constantes.CAPACITY_BBU);
        double tra = ct.getTransmissionDelay(fileSize, minCapacity);
        long delay = TOTAL_DELAY_TO_CN + lat + (long)tra; // add delay as downloaded from CN

        String str = isFile ? "sending FILE" : "sending piece";
        if (isFile)
            println(strPrint + "\t      bbu " + str + " to: " + container.node.getID() + " lat/transm: " + lat + "/" + Utils.TwoDec(tra), true);

        ct.send(delay, msgSent, container.node, pidrrh, TransportContainer.HowSend.RELIABLE);

        MsgRecoverBandwidth bwMsg = new MsgRecoverBandwidth(idBBU, fileSize, MsgRecoverBandwidth.What.FILE);
        ct.send(delay, bwMsg, thisNode, pid, TransportContainer.HowSend.RELIABLE);
        ct.send(delay, bwMsg, container.node, pidrrh, TransportContainer.HowSend.RELIABLE);

        return true;
    }
    
    public Object clone() {
        println("clone", false);
        ProtBBU protBBU = new ProtBBU(prefix);
        return protBBU;
    }


    private void println(String str, boolean print) {
        if(print) System.out.println("[ProtBBU] (" + idBBU + ") " + str + " -- " + CommonState.getTime());
    }
}
