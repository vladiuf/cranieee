package peersim.cran.components;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Set;

import peersim.cran.Constantes;

public class MEC {
    
    //              idFile
    private HashSet<Integer> filesMEC = new HashSet<>();

    //                idFile      idRRH
    private Hashtable<Integer,Set<Long>> filesOtherMECs = new Hashtable<>();

    private double currentStoreSize;

    public MEC() {

    }

    public boolean myHasStoredFile(int idFile) {
        if (filesMEC.contains(idFile)) return true;
        else return false;
    }

    public void myStoreFile(int idFile) {
        if (! filesMEC.contains(idFile)) currentStoreSize += Constantes.FILE_SIZE;
        filesMEC.add(idFile);
    }

    public boolean otherHasStoredFile(int idFile) {
        if (filesOtherMECs.get(idFile) != null) return true;
        else return false;
    }

    public void otherStoreFile(int idFile, long idRRH) {
        Set<Long> list = filesOtherMECs.get(idFile);
        if (list == null) list = new HashSet<>();
        list.add(idRRH);
        filesOtherMECs.put(idFile, list);
    }

    public Set<Long> getOthersHasFile(int idFile) {
        return filesOtherMECs.getOrDefault(idFile, new HashSet<Long>());
    }

    public boolean hasSpaceToStore(int idFile) {

        if (Constantes.USE_VIDEOS_REQUESTS_STATIONARY) {
            if (idFile > Constantes.MAX_VIDEOS_STORED_ZIPF) { // dont store if not allowed
                return false;
            }
        }

        //System.out.println("currstore:" + currentStoreSize + " filesize: " + Constantes.FILE_SIZE + " total: " + Constantes.STORAGE_MEC);
        if (currentStoreSize + Constantes.FILE_SIZE <= Constantes.STORAGE_MEC) {
            return true;
        } else {
            return false;
        }
    }
}
