package peersim.cran.components;

public class Config {
    public double SIZE_PIECE; // size of each piece in kilobytes
    public double CAPACITY_UE; // bandwith capacity of the ue in kilobytes/sec
    public double CAPACITY_RRH2UE; // bandwith capacity of the ue-rrh channel in kilobytes/sec
    public double CAPACITY_RRH; // bandwith capacity of the rrh in kilobytes/sec
    public double CAPACITY_BBU; // bandwith capacity of the rrh in kilobytes/sec

    public long LOOP_RRH_SEND_PIECE_TO_UE; // milliseconds
    public long LOOP_UE_SEND_REQ_TO_RRH; // milliseconds
    public long LOOP_BBU_SEND_FILE_TO_RRH; // milliseconds
    public int MAX_UE_PIECE_REQUEST;
    public int AMOUNT_PIECES;
    public double STORAGE_MEC; // in kilobytes
    
    /**
     * @param cAPACITY_UE must be the same as cAPACITY_RRH2UE.
     * @param cAPACITY_RRH2UE must be the same as cAPACITY_UE.
     */
    public Config(double sIZE_PIECE, double cAPACITY_UE, double cAPACITY_RRH2UE, double cAPACITY_RRH, double cAPACITY_BBU,
            long lOOP_RRH_SEND_PIECE_TO_UE, long lOOP_UE_SEND_REQ_TO_RRH, long lOOP_BBU_SEND_FILE_TO_RRH,
            int mAX_UE_PIECE_REQUEST, int aMOUNT_PIECES, double capacityStorageMEC) {
        this.SIZE_PIECE = sIZE_PIECE;
        this.CAPACITY_UE = cAPACITY_UE;
        this.CAPACITY_RRH2UE = cAPACITY_RRH2UE;
        this.CAPACITY_RRH = cAPACITY_RRH;
        this.CAPACITY_BBU = cAPACITY_BBU;
        this.LOOP_RRH_SEND_PIECE_TO_UE = lOOP_RRH_SEND_PIECE_TO_UE;
        this.LOOP_BBU_SEND_FILE_TO_RRH = lOOP_BBU_SEND_FILE_TO_RRH;
        this.LOOP_UE_SEND_REQ_TO_RRH = lOOP_UE_SEND_REQ_TO_RRH;
        this.MAX_UE_PIECE_REQUEST = mAX_UE_PIECE_REQUEST;
        this.AMOUNT_PIECES = aMOUNT_PIECES;
        this.STORAGE_MEC = capacityStorageMEC;
    }
}
