package peersim.cran.components;

import peersim.core.Node;
import peersim.cran.msgs.Msg;

public class NodeContainer {
    public Msg.WhoSend whoSend;
    public Node node;

    public NodeContainer(Msg.WhoSend who, Node node) {
        this.whoSend = who;
        this.node = node;
    }
}
