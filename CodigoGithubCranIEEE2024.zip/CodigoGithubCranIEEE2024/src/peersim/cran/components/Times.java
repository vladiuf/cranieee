package peersim.cran.components;

public class Times {
    
    public long initTime;
    public long endTime;

    public Times(long initTime) {
        this.initTime = initTime;
    }

    public void setEndTime(long endTime) {
        this.endTime = endTime;
    }

    public long delay() {
        return (endTime - initTime);
    }
}
