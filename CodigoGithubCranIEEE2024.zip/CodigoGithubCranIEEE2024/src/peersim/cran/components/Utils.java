package peersim.cran.components;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class Utils {
    
    private static DecimalFormat df = new DecimalFormat("0.00");
    private static DecimalFormatSymbols dfs = DecimalFormatSymbols.getInstance();

    static {
        dfs.setDecimalSeparator(',');
        df = new DecimalFormat("0.00", dfs);
    }

    public static double timeSimulationInSeconds(long time) {
        double dTime = time + 0.0;
        return dTime/1000.0;
    }

    public static String TwoDec(double value) {
        return df.format(value);
    }

    public static double kiloToGiga(double kilo) {
        return (kilo / (1000.0*1000.0));
    }
}
