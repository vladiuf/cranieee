package peersim.cran.movements;

import peersim.core.Protocol;

public class CoordinateKeeper implements Protocol {
    
    /** 2d coordinates components. */
    private double centerX, centerY;
    private double x, y;
    
    /** The mobile. If the node is mobile set this to true */
    private boolean mobile;

    public CoordinateKeeper(String prefix) {
        /* Un-initialized coordinates defaults to -1. */
        centerX = 0.0;
        centerY = 0.0;
        x = -1;
        y = -1;
        mobile = true;
    }

    public double distanceToCenter() {
        return Math.sqrt((y - centerY) * (y - centerY) + (x - centerX) * (x - centerX));
    }

    public Object clone() {
    	CoordinateKeeper inp = null;
        try {
            inp = (CoordinateKeeper) super.clone();
        } catch (CloneNotSupportedException e) {} // never happens
        inp.x = -1;
        inp.y = -1;
        inp.mobile = true;
        return inp;
    }

    public double getCenterX() {
        return centerX;
    }

    public double getCenterY() {
        return centerY;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

	public boolean isMobile() {
		return mobile;
	}

	public void setMobile(boolean Mobile) {
		this.mobile = Mobile;
	}
}
