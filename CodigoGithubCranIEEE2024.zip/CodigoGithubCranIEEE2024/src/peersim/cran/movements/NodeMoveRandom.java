package peersim.cran.movements;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;

public class NodeMoveRandom implements Control {
    
    /** The coordinates pid. */
    public int coordinatesPid;

    //public static double centerX = 0.0, centerY = 0.0;
    public double radius = 1.0;

    public NodeMoveRandom (String prefix){
    
        coordinatesPid 	= Configuration.getPid(prefix + "." + "coord");
        //radius = Configuration.getPid(prefix + "." + "radius");
    }

    public boolean execute() {

        //println("Executed at", true);
        for (int i=0; i<Network.size(); i++){
            Node node = Network.get(i);
            CoordinateKeeper coordinates = (CoordinateKeeper) node.getProtocol(coordinatesPid);
            if(coordinates.isMobile()){
                // generate a random point inside a circle
                double r = radius * Math.sqrt(CommonState.r.nextDouble());
                double theta = CommonState.r.nextDouble() * 2.0 * Math.PI;

                coordinates.setX(coordinates.getCenterX() + r * Math.cos(theta));
                coordinates.setY(coordinates.getCenterY() + r * Math.sin(theta));
            }
        }
        return false;
    }

}
