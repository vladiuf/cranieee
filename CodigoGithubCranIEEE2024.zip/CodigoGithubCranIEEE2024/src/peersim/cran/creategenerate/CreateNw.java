package peersim.cran.creategenerate;

import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.cran.protocols.ProtUE;

public class CreateNw implements Control {

    private static final String PAR_PROT = "protocol";
    private int pid = 0;

    public CreateNw(String prefix) {
		pid = Configuration.getPid(prefix + "." + PAR_PROT);
	}

    @Override
    public boolean execute() {
        // criando os user equipment UE
        for (int i = 0; i < Network.size(); i++) {
			Node node = (Node) Network.get(i);
            ProtUE ue = (ProtUE) node.getProtocol(pid);
            ue.idUE = node.getID();
        }

        // criando os rrh

        // criando as bbu

        return false;
    }
    

}