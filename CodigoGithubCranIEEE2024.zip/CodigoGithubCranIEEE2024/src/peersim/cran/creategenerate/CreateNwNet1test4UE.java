package peersim.cran.creategenerate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.cran.Constantes;
import peersim.cran.msgs.MsgStart;
import peersim.cran.protocols.ProtUE;
import peersim.cran.transport.TransportContainer;
import peersim.edsim.EDSimulator;

public class CreateNwNet1test4UE implements Control {
 
    private static final String PAR_PROT_BBU = "protocolbbu";
    private static final String PAR_PROT_RRH = "protocolrrh";
    private static final String PAR_PROT_UE = "protocolue";
    private int pidbbu = 0;
    private int pidrrh = 0;
    private int pidue = 0;

    int AMOUNT_BBUs = 1;
    int AMOUNT_RRHs = 2;

    public CreateNwNet1test4UE(String prefix) {
        pidbbu = Configuration.getPid(prefix + "." + PAR_PROT_BBU);
		pidrrh = Configuration.getPid(prefix + "." + PAR_PROT_RRH);
        pidue = Configuration.getPid(prefix + "." + PAR_PROT_UE);
	}

    @Override
    public boolean execute() {

        List<Long> indexes_rrhs = Arrays.asList(1L, 2L);
        Constantes.IDS_RRHs = indexes_rrhs;

        /*
         *             BBU0
         *          /         \
         *      router1     router2
         *        |             |
         *      RRH1           RRH2
         *    /  |  \           |
         *  UE3 UE4 UE5        UE6
         *  f1  f2  f1         f2
         * 
         * 
         *  f1 is file1, f2 is file2
         */


        TransportContainer tc = new TransportContainer();

        // inicializando arquivos e pecas a serem baixados pelos UE
        int ID_FILE1 = 1;
        int ID_FILE2 = 2;
        int AMOUNT_PIECES = Constantes.AMOUNT_PIECES;
        
        MsgStart start = new MsgStart();

        // criando as bbu
        Node nodebbu = (Node) Network.get(0);
        MsgStart startBBU = new MsgStart();
        startBBU.id = nodebbu.getID();
        startBBU.node = null;
        startBBU.tc = tc;
        EDSimulator.add(7, startBBU, nodebbu, pidbbu); // start bbu

        // criando os 2 rrh one for each router
        int idrouter = 1;
        Node noderrh1 = (Node) Network.get(1);    
        MsgStart startRRH = new MsgStart();
        startRRH.id = noderrh1.getID();
        startRRH.node = nodebbu;
        startRRH.tc = tc;
        startRRH.idrouter = idrouter;
        EDSimulator.add(50, startRRH, noderrh1, pidrrh); // start rrh
        
        idrouter++;
        Node noderrh2 = (Node) Network.get(2);    
        startRRH = new MsgStart();
        startRRH.id = noderrh2.getID();
        startRRH.node = nodebbu;
        startRRH.tc = tc;
        startRRH.idrouter = idrouter;
        EDSimulator.add(50, startRRH, noderrh2, pidrrh); // start rrh

        int idrrh = 1;
        int initAt = 100;
        int ID_FILE = ID_FILE1;
        for (int i = 3; i < Network.size(); i++) {
            if (i == 6) idrrh = 2;
            Node node = (Node) Network.get(i);
            ProtUE ue = (ProtUE) node.getProtocol(pidue);
            Node rrh = Network.get(idrrh);
            //System.out.println("id ue: " + node.getID() + " idx: " + node.getIndex() + " idrrh: " + idrrh);
            if (i == 4 || i == 6) ID_FILE = ID_FILE2;
            else ID_FILE = ID_FILE1;
            ue.init(node.getID(), tc, rrh, ID_FILE, AMOUNT_PIECES);
            EDSimulator.add(initAt, start, node, pidue); // start ue
            initAt += 1000;
        }

        return false;
    }
}
