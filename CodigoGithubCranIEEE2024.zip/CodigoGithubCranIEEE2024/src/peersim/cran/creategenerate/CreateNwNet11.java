package peersim.cran.creategenerate;

import peersim.config.Configuration;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.cran.Constantes;
import peersim.cran.msgs.MsgStart;
import peersim.cran.protocols.ProtBBU;
import peersim.cran.protocols.ProtRRH;
import peersim.cran.protocols.ProtUE;
import peersim.cran.transport.TransportContainer;
import peersim.edsim.EDSimulator;

public class CreateNwNet11  implements Control {

    private static final String PAR_PROT_BBU = "protocolbbu";
    private static final String PAR_PROT_RRH = "protocolrrh";
    private static final String PAR_PROT_UE = "protocolue";
    private int pidbbu = 0;
    private int pidrrh = 0;
    private int pidue = 0;

    int AMOUNT_BBUs = 1;
    int AMOUNT_RRHs = 21;

    public CreateNwNet11(String prefix) {
        pidbbu = Configuration.getPid(prefix + "." + PAR_PROT_BBU);
		pidrrh = Configuration.getPid(prefix + "." + PAR_PROT_RRH);
        pidue = Configuration.getPid(prefix + "." + PAR_PROT_UE);
	}

    @Override
    public boolean execute() {
        System.out.println("[CreateNewNet11] execute Network size: " + Network.size());
        if (Network.size() < AMOUNT_RRHs + AMOUNT_BBUs) {
            System.out.println("[CreateNewNet11] You need more nodes");
            System.exit(0);
        }

        TransportContainer tc = new TransportContainer();

        // inicializando arquivos e pecas a serem baixados pelos UE
        int ID_FILE = 1;
        int AMOUNT_PIECES = Constantes.AMOUNT_PIECES;
        
        MsgStart start = new MsgStart();

        // criando as bbu
        Node nodebbu = (Node) Network.get(0);
        MsgStart startBBU = new MsgStart();
        startBBU.id = nodebbu.getID();
        startBBU.node = null;
        startBBU.tc = tc;
        EDSimulator.add(7, startBBU, nodebbu, pidbbu); // start bbu

        // criando os 21 rrh
        int idrouter = 1;
        for (int i = 1; i < AMOUNT_RRHs+1; i++) { // there are 21 RRHs
            Node noderrh = (Node) Network.get(i);    
            MsgStart startRRH = new MsgStart();
            startRRH.id = noderrh.getID();
            startRRH.node = nodebbu;
            startRRH.tc = tc;
            startRRH.idrouter = idrouter;
            EDSimulator.add(50, startRRH, noderrh, pidrrh); // start rrh
            if (i % 3 == 0) idrouter++;
        }
        

        // criando os user equipment UE. distribuindo nos rrh de forma uniforme
        int idrrh = 1;
        for (int i = AMOUNT_RRHs+1; i < Network.size(); i++) {
            if (idrrh > AMOUNT_RRHs) idrrh = 1;
			Node node = (Node) Network.get(i);
            ProtUE ue = (ProtUE) node.getProtocol(pidue);
            Node rrh = Network.get(idrrh);
            //System.out.println("id ue: " + node.getID() + " idx: " + node.getIndex());
            ue.init(node.getID(), tc, rrh, ID_FILE, AMOUNT_PIECES);
            EDSimulator.add(100, start, node, pidue); // start ue
            idrrh++;
        }

        
        

        return false;
    }
    
    
}

