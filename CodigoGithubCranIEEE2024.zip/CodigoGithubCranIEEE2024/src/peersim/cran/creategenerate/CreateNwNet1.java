package peersim.cran.creategenerate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;

import org.apache.commons.math3.distribution.PoissonDistribution;
import org.apache.commons.math3.distribution.ZipfDistribution;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.cran.Constantes;
import peersim.cran.components.Utils;
import peersim.cran.msgs.MsgStart;
import peersim.cran.protocols.ProtUE;
import peersim.cran.transport.TransportContainer;
import peersim.edsim.EDSimulator;

public class CreateNwNet1 implements Control {
 
    private static final String PAR_PROT_BBU = "protocolbbu";
    private static final String PAR_PROT_RRH = "protocolrrh";
    private static final String PAR_PROT_UE = "protocolue";
    private int pidbbu = 0;
    private int pidrrh = 0;
    private int pidue = 0;

    int AMOUNT_BBUs = 1;
    int AMOUNT_RRHs = 21;

    //PoissonDistribution pd = new PoissonDistribution(Constantes.LAMBDA_POISSON);
    List<Double> cdfsPoisson = new ArrayList<>();

    public CreateNwNet1(String prefix) {
        pidbbu = Configuration.getPid(prefix + "." + PAR_PROT_BBU);
		pidrrh = Configuration.getPid(prefix + "." + PAR_PROT_RRH);
        pidue = Configuration.getPid(prefix + "." + PAR_PROT_UE);
	}

    @Override
    public boolean execute() {

        //initPoisson();

        //List<Long> indexes_rrhs = Arrays.asList(1L, 2L);
        List<Long> indexes_rrhs = new ArrayList<>();
        for (int i = 1; i < AMOUNT_RRHs+1; i++) {
            indexes_rrhs.add(new Long(i));
        }
        System.out.println("RRHs IDs: " + indexes_rrhs.toString());

        Constantes.IDS_RRHs = indexes_rrhs;


        TransportContainer tc = new TransportContainer();

        int AMOUNT_PIECES = Constantes.AMOUNT_PIECES;
        
        MsgStart start = new MsgStart();

        // creating bbu
        Node nodebbu = (Node) Network.get(0);
        MsgStart startBBU = new MsgStart();
        startBBU.id = nodebbu.getID();
        startBBU.node = null;
        startBBU.tc = tc;
        EDSimulator.add(7, startBBU, nodebbu, pidbbu); // start bbu

        // creating 21 rrh
        int idrouter = 1;
        for (int i = 1; i < AMOUNT_RRHs+1; i++) { // there are 21 RRHs
            Node noderrh = (Node) Network.get(i);    
            MsgStart startRRH = new MsgStart();
            startRRH.id = noderrh.getID();
            startRRH.node = nodebbu;
            startRRH.tc = tc;
            startRRH.idrouter = idrouter;
            EDSimulator.add(50+i, startRRH, noderrh, pidrrh); // start rrh
            if (i % 3 == 0) idrouter++;
        }
        
        RandomGenerator rnd = new Well19937c(CommonState.r.getLastSeed());
        ZipfDistribution zipfVids = new ZipfDistribution(rnd, Constantes.AMOUNT_VIDEOS, Constantes.EXPONENT_VIDEOS_ZIPF);
        
        Hashtable<Integer, List<String>> vidsRequested = new Hashtable<>();
        int idrrh = 1;
        int initAt = 1000;
        int TOTAL_UEs = Network.size() - (AMOUNT_RRHs+1); // network.size 26 # 1 bbu + 21 rrh + 4 ues
        int currentUEs = 0;
        int samplesZipf = 0;
        String repeatedStr = "";
        while (currentUEs < TOTAL_UEs) { // 0=bbu 1-21=rrh 22-25=ue
            int qty = getAmountUEs();
            System.out.println("[CreateNwNet1] creating " + qty + " nodes at: " + initAt);
            for (int i = 0; i < qty; i++) {
                if (currentUEs < TOTAL_UEs) {
                    int idUE = currentUEs + AMOUNT_RRHs+1;
                    if (idrrh > AMOUNT_RRHs) idrrh = 1;
                    Node node = (Node) Network.get(idUE);
                    ProtUE ue = (ProtUE) node.getProtocol(pidue);
                    Node rrh = Network.get(idrrh);
                    int ID_FILE = zipfVids.sample();
                    samplesZipf++;
                    List<String> list = vidsRequested.getOrDefault(ID_FILE, new ArrayList<>());
                    list.add("id:" + node.getID() + " init:" + initAt + " rrh:" + idrrh);
                    vidsRequested.put(ID_FILE, list);
                    ue.init(node.getID(), tc, rrh, ID_FILE, AMOUNT_PIECES);
                    EDSimulator.add(initAt, start, node, pidue); // start ue
                    idrrh++;
                    currentUEs++;        
                }
            }
            initAt += Constantes.NEXT_TIME_CREATION; // next time unit
        }

        String repeatedStrItem = "";
        for (Integer idfile : vidsRequested.keySet()) {
            repeatedStrItem = "File: " + idfile;
            List<String> nodesStr = vidsRequested.get(idfile);
            if (nodesStr.size() > 1) {
                for (String sn : nodesStr) {
                    repeatedStrItem += "\t [" + sn + "]";
                }
                repeatedStr += repeatedStrItem + "\n";
            }
        }

        int repeated = samplesZipf - vidsRequested.size();
        double ratio = (vidsRequested.size() + 0.0) / currentUEs;
        Constantes.logCreation = "[CreateNwNet1] currentUEs: " + currentUEs + " sampling zip: " + samplesZipf + " hashsize: " + vidsRequested.size() + " repeated: " + repeated + " ratio: " + Utils.TwoDec(ratio);
        Constantes.logCreationRepeated = "RepeatedZipf " + repeated + " Total " + samplesZipf;

        System.out.println(repeatedStr);
        System.out.println(Constantes.logCreation);

        //System.exit(0);
        return false;
    }

    /*private void initPoisson() {
        int total = 4 * (int)Constantes.LAMBDA_POISSON;
        for (int i = 0; i < total; i++) {
            cdfsPoisson.add(pd.cumulativeProbability(i));
        }
    }*/

    private int getAmountUEs() {
        /*double rand = CommonState.r.nextDouble();
        for (int i = 0; i < cdfsPoisson.size(); i++) {
            if (rand < cdfsPoisson.get(i)) {
                return i;
            }
        }
        int total = 4 * (int)Constantes.LAMBDA_POISSON;
        return total;*/
        
        return CommonState.r.nextPoisson(Constantes.LAMBDA_POISSON);
    }
}

