package peersim.cran.creategenerate;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.cran.msgs.MsgPing;
import peersim.edsim.EDSimulator;

public class TrafficGeneratorPingPong implements Control {

    private static final String PAR_PROT = "protocol";
	private final int pid;
    private int executou = 0;

    public TrafficGeneratorPingPong(String prefix) {
		pid = Configuration.getPid(prefix + "." + PAR_PROT);
	}

    @Override
    public boolean execute() {
        if(0 == executou) {
			executou = 1;
            int size = Network.size();
            for(int i = 0; i < size; i++) {
                Node ueSrc = Network.get(i);
                Node ueDst = Network.get(CommonState.r.nextInt(size));
                
                MsgPing ping = new MsgPing("olá", ueDst);
                EDSimulator.add(10, ping, ueSrc, pid);
            }

        }

        return false;
    }
    
}
