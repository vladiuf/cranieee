package peersim.cran;

import java.util.Hashtable;
import java.util.List;

import com.google.common.primitives.Longs;

import peersim.cran.components.Config;

public class Constantes {
    
    public static long idMsgCount = 0;
    public static double SIZE_PIECE; // size of each piece in kilobytes
    public static double CAPACITY_UE; // bandwith capacity of the ue in kilobytes/sec
    public static double CAPACITY_RRH2UE; // bandwith capacity of the ue-rrh channel in kilobytes/sec
    public static double CAPACITY_RRH; // bandwith capacity of the rrh in kilobytes/sec
    public static double CAPACITY_BBU; // bandwith capacity of the bbu in kilobytes/sec

    public static long LOOP_RRH_SEND_PIECE_TO_UE; // milliseconds
    public static long LOOP_UE_SEND_REQ_TO_RRH; // milliseconds
    public static long LOOP_BBU_SEND_FILE_TO_RRH; // milliseconds
    public static int MAX_UE_PIECE_REQUEST;
    public static int AMOUNT_PIECES;
    public static double STORAGE_MEC;
    public static double FILE_SIZE; // calculated
    public static long LATENCY_BBU_CN;
    public static long LATENCY_NEIGHBORS_RRH;
    public static long LATENCY_BBU_RRH;
    public static long LATENCY_UE_RRH;
    public static List<Long> IDS_RRHs;
    public static int TOPOLOGY_NETWORK; // 1. ring. 2. other
    public final static int TOPOLOGY_RING = 1;
    
    
    public static Hashtable<String,Config> configs = new Hashtable<>();
    public static int AMOUNT_VIDEOS;
    public static int MAX_VIDEOS_STORED;
    public static int MAX_VIDEOS_STORED_ZIPF;
    public static double EXPONENT_VIDEOS_ZIPF;
    public static double LAMBDA_POISSON;
    public static long NEXT_TIME_CREATION; // milliseconds
    //public static long END_SIMULATION_AT;
    public static boolean USE_MOBILITY;
    public static boolean USE_VIDEOS_REQUESTS_STATIONARY;

    public static enum SPEED {FAST, SLOW};
    public static SPEED choosenLatSpeed;

    public static String logCreation;
    public static String logCreationRepeated;
    
    
    
    static {
        @SuppressWarnings("unused")
        Config testMaxCapacity = 
                        new Config(1000.0, 4000.0, 4000.0, 16000.0, 16000.0, 
                                            500L, 500L, 500L, 
                                            4, 4, 1000.0);


        /*capacity_ue == 100 requests = 20
        capacity_ue == 500 requests = 100*/
        double mega = 1000.0;
        double giga = mega * mega;
        double capacity_ue = 0.5*giga;
        int amountPieces = 1000;

        SIZE_PIECE = mega; 
        AMOUNT_PIECES = amountPieces;
        AMOUNT_VIDEOS = 1512;
        MAX_VIDEOS_STORED = (int) (0.250 * AMOUNT_VIDEOS);
        FILE_SIZE = SIZE_PIECE * (AMOUNT_PIECES + 0.0);


        Config testReal1 = new Config(SIZE_PIECE, capacity_ue, capacity_ue, giga, 1*giga, 
                50L, 50L, 50L, 
                (int)(capacity_ue*0.2/1000), amountPieces, MAX_VIDEOS_STORED*FILE_SIZE);
                // para 300 nodes EXPONENT_VIDEOS_ZIPF 0.271
                // sampling zip: 278 hashsize: 252 repeated: 26
                // para 300 nodes EXPONENT_VIDEOS_ZIPF 0.971
                // sampling zip: 278 hashsize: 158 repeated: 120
                // 10.0 * giga = 0.91
                // para 300 nodes EXPONENT_VIDEOS_ZIPF 1.971
                // sampling zip: 278 hashsize: 20 repeated: 258
                // 1.0 * giga = 0.90

        Config choosen = testReal1;

        Hashtable<SPEED, List<Long>> latencies = new Hashtable<>();

        latencies.put(SPEED.SLOW, Longs.asList(160, 160, 160, 160)); // in milliseconds
        latencies.put(SPEED.FAST, Longs.asList(40, 40, 40, 40)); // in milliseconds
        choosenLatSpeed = SPEED.SLOW;
        

        
        CAPACITY_UE = choosen.CAPACITY_UE;
        CAPACITY_RRH2UE = choosen.CAPACITY_RRH2UE; 
        CAPACITY_RRH = choosen.CAPACITY_RRH;
        CAPACITY_BBU = choosen.CAPACITY_BBU;

        LOOP_RRH_SEND_PIECE_TO_UE = choosen.LOOP_RRH_SEND_PIECE_TO_UE; 
        LOOP_UE_SEND_REQ_TO_RRH = choosen.LOOP_UE_SEND_REQ_TO_RRH; 
        LOOP_BBU_SEND_FILE_TO_RRH = choosen.LOOP_BBU_SEND_FILE_TO_RRH;
        MAX_UE_PIECE_REQUEST = choosen.MAX_UE_PIECE_REQUEST;
        
        STORAGE_MEC = choosen.STORAGE_MEC;

        List<Long> choosenLat = latencies.get(choosenLatSpeed);
        LATENCY_BBU_CN = choosenLat.get(0); // milliseconds
        LATENCY_NEIGHBORS_RRH = choosenLat.get(1); // milliseconds
        LATENCY_BBU_RRH = choosenLat.get(2); // milliseconds
        LATENCY_UE_RRH = choosenLat.get(3); // milliseconds

        TOPOLOGY_NETWORK = TOPOLOGY_RING;
        EXPONENT_VIDEOS_ZIPF = 1.0; // 0.271 video paper´// 0.7 e 1.0
        LAMBDA_POISSON = 1.0;
        NEXT_TIME_CREATION = 1000; // 1000 (1 per second)

        //END_SIMULATION_AT = 500000; // milliseconds
        USE_MOBILITY = true;
        USE_VIDEOS_REQUESTS_STATIONARY = false;
        MAX_VIDEOS_STORED_ZIPF = 2 * MAX_VIDEOS_STORED;

        System.out.println("[Constantes] static. FileSize: " + FILE_SIZE);
        System.out.println("[Constantes] static. StorageMEC: " + STORAGE_MEC);
        //System.exit(0);
    }

}