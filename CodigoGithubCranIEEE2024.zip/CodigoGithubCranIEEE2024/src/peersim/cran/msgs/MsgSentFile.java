package peersim.cran.msgs;

public class MsgSentFile extends Msg {

    public int idFile;

    public MsgSentFile(int idFile) {
        super(null, null, -1);
        this.idFile = idFile;
    }
    
}
