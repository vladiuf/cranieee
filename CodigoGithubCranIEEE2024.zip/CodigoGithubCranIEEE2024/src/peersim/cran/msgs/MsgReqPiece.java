package peersim.cran.msgs;

import peersim.core.Node;

public class MsgReqPiece extends Msg {

    public int idFile;
    public int idPiece;

    public MsgReqPiece(Node src, WhoSend who, int idFile, int idPiece, long time) {
        super(src, who, time);
        this.idFile = idFile;
        this.idPiece = idPiece;
    }

}
