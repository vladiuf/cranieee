package peersim.cran.msgs;

public class MsgRecoverBandwidth {
    
    public long idSrc;
    public double size;
    public What what;

    public enum What {
        FILE, PIECE;
    }

    public MsgRecoverBandwidth(long idSrc, double size, What what) {
        this.idSrc = idSrc;
        this.size = size;
        this.what = what;
    }
}
