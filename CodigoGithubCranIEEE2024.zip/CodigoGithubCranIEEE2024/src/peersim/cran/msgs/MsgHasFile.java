package peersim.cran.msgs;

public class MsgHasFile {

    public int idfile;
    public long rrhHasFile;

    public MsgHasFile(int idFile, long idRRH) {
        this.idfile = idFile;
        this.rrhHasFile = idRRH;
    }
    
}
