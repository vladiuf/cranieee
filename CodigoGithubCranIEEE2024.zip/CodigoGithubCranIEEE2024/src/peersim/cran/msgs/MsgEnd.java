package peersim.cran.msgs;

public class MsgEnd {
    
}
