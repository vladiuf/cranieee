package peersim.cran.msgs;

import peersim.core.Node;

public class MsgSentPiece extends Msg {

    public long idMsgReq; // identifier of the message requesting the piece
    public int idFile;
    public int idPiece;
    public long idrrh;

    public MsgSentPiece(long idMsgReq, Node src, WhoSend who, int idFile, int idPiece, long idrrh, long time) {
        super(src, who, time);
        this.idMsgReq = idMsgReq;
        this.idFile = idFile;
        this.idPiece = idPiece;
        this.idrrh = idrrh;
    }
    
}
