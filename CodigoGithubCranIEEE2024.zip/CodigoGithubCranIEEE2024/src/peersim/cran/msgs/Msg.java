package peersim.cran.msgs;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

import peersim.core.Node;
import peersim.cran.Constantes;
import peersim.cran.components.NodeContainer;

public class Msg {
    
    public long idMsg;
    public Node src;
    public WhoSend who;
    public long time;

    public List<NodeContainer> intermediaries = new ArrayList<>();

    public enum WhoSend {
        UE, RRH, BBU;
    }

    public Msg(Node src, WhoSend who, long time) {
        this.idMsg = Constantes.idMsgCount++;
        this.src = src;
        this.who = who;
        this.time = time;
    }

    public void addIntermediary(NodeContainer nodeContainer) {
        intermediaries.add(nodeContainer);
    }

    public NodeContainer getLastIntermediary() {
        return intermediaries.get(intermediaries.size()-1);
    }

    public void removeIntermediary(long id) {

        ListIterator<NodeContainer> listIterator = intermediaries.listIterator(intermediaries.size());
        while (listIterator.hasPrevious()) {
            NodeContainer container = listIterator.previous();
            if (container.node.getID() == id) {
                listIterator.remove();
                break;
            }
        }
    }
}
