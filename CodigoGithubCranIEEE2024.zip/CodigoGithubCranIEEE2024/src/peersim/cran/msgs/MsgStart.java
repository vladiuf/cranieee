package peersim.cran.msgs;

import peersim.core.Node;
import peersim.cran.transport.TransportContainer;

public class MsgStart {
    public long id;
    public Node node;
    public TransportContainer tc;
    public int idrouter;
    
}
