package peersim.cran.msgs;

import peersim.core.Node;

public class MsgPong {
    
    public Node sender;
    public String msg;
    
    public MsgPong(String msg, Node sender) {
        this.msg = msg;
        this.sender = sender;
    }
}