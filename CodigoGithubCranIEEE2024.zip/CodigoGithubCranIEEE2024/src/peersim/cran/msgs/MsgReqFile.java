package peersim.cran.msgs;

import peersim.core.Node;

public class MsgReqFile extends Msg {
    
    public int idFile;

    public MsgReqFile(Node src, WhoSend who, int idFile, long time) {
        super(src, who, time);
        this.idFile = idFile;
    }
}
