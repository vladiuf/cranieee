package peersim.cran.msgs;

import peersim.core.Node;

public class MsgPing {
    
    public Node dest;
    public String msg;
    
    public MsgPing(String msg, Node dest) {
        this.msg = msg;
        this.dest = dest;
    }
}
