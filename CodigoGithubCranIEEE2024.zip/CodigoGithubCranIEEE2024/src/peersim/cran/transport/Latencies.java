package peersim.cran.transport;

public class Latencies {
    
    public static long getLatencyUERRH(double distance, boolean more) {

        // 27.4. Table 2. A First Look at Commercial 5G Performance on Smartphones 27.4 +- 6.4
        if (more)
            return (long)(27.4 + (distance * 6.4));
        else
        return (long)(27.4 - (distance * 6.4));
    }
}
