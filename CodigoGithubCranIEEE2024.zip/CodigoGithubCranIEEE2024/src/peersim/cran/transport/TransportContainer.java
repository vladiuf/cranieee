package peersim.cran.transport;

import java.util.Iterator;
import java.util.Set;

import peersim.core.CommonState;
import peersim.core.Network;
import peersim.core.Node;
import peersim.cran.Constantes;
import peersim.cran.movements.CoordinateKeeper;
import peersim.cran.protocols.ProtRRH;
import peersim.cran.protocols.ProtUE;
import peersim.edsim.EDSimulator;

/**
 * Same funcionalities of class peersim.transport.Transport
 * But specific to the network topology
 */
public class TransportContainer {

    public enum HowSend {
        RELIABLE, UNRELIABLE;
    }
    
    public void send(long delay, Object msg, Node dest, int pid, HowSend how) {
        if (how == HowSend.RELIABLE)
            EDSimulator.add(delay, msg, dest, pid);

        // TODO unreliable with drop must alert destination 'dest' that msg was drop (to retry)
    }

    public long getLatency(Node src, Node dest, int pidSrc, int pidDest, Integer pidcoord) {
        if (Constantes.TOPOLOGY_NETWORK == Constantes.TOPOLOGY_RING) {
            long sumLatency = 0;

            int pidrrh = -1; // there always have at least one rrh to set this variable
            long idSrc = src.getID();
            long idDest = dest.getID();

            if (idSrc == 0 || idDest == 0) { //it is a bbu
                return Constantes.LATENCY_BBU_RRH;
            }

            Node rrhSrc;
            if (! Constantes.IDS_RRHs.contains(idSrc)) { // src is a ue
                ProtUE srcProt = (ProtUE) src.getProtocol(pidSrc); 
                rrhSrc = srcProt.rrh;
                if (pidcoord == null) {
                    sumLatency += Constantes.LATENCY_UE_RRH;
                } else {
                    CoordinateKeeper coordinates = (CoordinateKeeper) src.getProtocol(pidcoord.intValue());
                    sumLatency += Latencies.getLatencyUERRH(coordinates.distanceToCenter(), CommonState.r.nextBoolean());
                }
            } else {
                rrhSrc = src;
                pidrrh = pidSrc;
            }

            Node rrhDest;
            if (! Constantes.IDS_RRHs.contains(idDest)) { // src is a ue
                ProtUE destProt = (ProtUE) dest.getProtocol(pidDest); 
                rrhDest = destProt.rrh;
                if (pidcoord == null) {
                    sumLatency += Constantes.LATENCY_UE_RRH;
                } else {
                    CoordinateKeeper coordinates = (CoordinateKeeper) src.getProtocol(pidcoord.intValue());
                    sumLatency += Latencies.getLatencyUERRH(coordinates.distanceToCenter(), CommonState.r.nextBoolean());
                }
            } else {
                rrhDest = dest;
                pidrrh = pidDest;
            }

            ProtRRH protRRHSrc = (ProtRRH) rrhSrc.getProtocol(pidrrh);
            ProtRRH protRRHDest = (ProtRRH) rrhDest.getProtocol(pidrrh);

            int distanceAbs = Math.abs(protRRHSrc.idRouter - protRRHDest.idRouter);
            int distanceRing = Math.min(distanceAbs, Constantes.IDS_RRHs.size() - distanceAbs); // distance in a ring

            return sumLatency + (Constantes.LATENCY_NEIGHBORS_RRH * distanceRing);

        } else {
            return 1;
        }
    }

    public long getLatency(Node src, Node dest, int pidSrc, int pidDest) {
        return getLatency(src, dest, pidSrc, pidDest, null);
    }

    /**
     * @param packetSize in kbits
     * @param capacitySize in kbits/second
     * @return
     */
    public double getTransmissionDelay(double packetSize, double capacitySize) {
        
        double delay = packetSize / capacitySize;
        return delay;
    }

    /**
     * There always be at least one otherRRHs
     * @param idRRH
     * @param otherRRHs
     * @param pidrrh
     * @return the nearest in hops
     * 
     */
    public Node getNearestRRH(long idRRH, Set<Long> otherRRHs, int pidrrh) {

        Iterator<Long> iterator = otherRRHs.iterator();
        if (otherRRHs.size() == 1) {
            long id = iterator.next();
            return Network.get((int)id);
        }
     
        Node meNode = Network.get((int)idRRH);
        ProtRRH me = (ProtRRH) meNode.getProtocol(pidrrh); 
        int meRouter = me.idRouter;

        Node nearest = null;
        int nearRouter = Integer.MAX_VALUE;

        if (Constantes.TOPOLOGY_NETWORK == Constantes.TOPOLOGY_RING) {
            while (iterator.hasNext()) {
                long otherId = iterator.next();
                if (idRRH == otherId) continue;
                Node otherNode = Network.get((int)otherId);
                ProtRRH other = (ProtRRH) otherNode.getProtocol(pidrrh); 
                int otherRouter = other.idRouter;

                int distanceAbs = Math.abs(meRouter - otherRouter);
                int distanceRing = Math.min(distanceAbs, Constantes.IDS_RRHs.size() - distanceAbs); // distance in a ring
                if (distanceRing < nearRouter) {
                    nearRouter = distanceRing;
                    nearest = otherNode;
                }
            }
        }

        return nearest;
    }
}
