package peersim.cran.control;

import java.util.ArrayList;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.stream.Collectors;

import peersim.config.Configuration;
import peersim.core.CommonState;
import peersim.core.Control;
import peersim.core.Network;
import peersim.core.Node;
import peersim.cran.Constantes;
import peersim.cran.components.Utils;
import peersim.cran.protocols.ProtUE;

public class ControlReport implements Control {

    public String prefix;
    private static final String PAR_PROT_UE = "protocolue";
    private int pidue;
    private boolean executed = false;
    private boolean printMy = false;
    private boolean printOther = false;
    private boolean printBoth = false;

    private long initTimeSimulation;

    public ControlReport(String prefix) {
        this.prefix = prefix;
        this.pidue = Configuration.getPid(prefix + "." + PAR_PROT_UE);
        initTimeSimulation = System.currentTimeMillis();
    }

    @Override
    public boolean execute() {
        
        long delaySimulation = System.currentTimeMillis() - initTimeSimulation;
        long delaySimInSec = delaySimulation/1000;

        
        if (executed) {
            //println("executed in: " + (delaySimInSec) + " sec " + (delaySimInSec/60) + " min", true);
            println("ALL SEEDERS exiting", true);
            System.exit(0);
            return false;
        } 

        // verifying all seed
        int seeders = 0;
        int countUEs = 0;
        for (int i = 1+Constantes.IDS_RRHs.size(); i < Network.size(); i++) { // there are 21 RRHs
            Node node = (Node) Network.get(i); 
            ProtUE ue = (ProtUE)node.getProtocol(pidue);
            if (ue.isSeeder()) seeders++;
            countUEs++;
        }
        
        List<Double[]> ods = new ArrayList<>();
        List<Double[]> delays = new ArrayList<>();
        //if (seeders == countUEs || CommonState.getTime() > Constantes.END_SIMULATION_AT) {
        if (seeders != countUEs) {
            println("seeders: " + seeders + " of " + countUEs + " executed in: " + (delaySimInSec) + " sec " + (delaySimInSec/60) + " min", true);
        } else { // all UEs are seeders
            System.out.println("");
            println("seeders: " + seeders + " of " + countUEs + " executed in: " + (delaySimInSec) + " sec " + (delaySimInSec/60) + " min", true);
            executed = true;
            int countOthers = 0;
            for (int i = 1+Constantes.IDS_RRHs.size(); i < Network.size(); i++) { // there are 21 RRHs
                Node node = (Node) Network.get(i); 
                ProtUE ue = (ProtUE)node.getProtocol(pidue);
                if (ue.isSeeder())  {
                    if (ue.whereDownloadedRRH() == 2) {
                        if (! printBoth) {
                            ue.printAllInfo();
                            printBoth = true;
                        }
                        countOthers++;
                    }
                    if (ue.whereDownloadedRRH() == 1) {
                        if (!printOther) {
                            ue.printAllInfo();
                            printOther = true;
                        }
                        countOthers++;
                    }
                    if (ue.whereDownloadedRRH() == 0) {
                        if (!printMy) {
                            ue.printAllInfo();
                            printMy = true;
                        }
                    }
                    
                    int piecesDw = ue.getPiecesDownloaded();
                    ods.add(ue.calculateOperationalDownloads(piecesDw));
                    delays.add(ue.averagePiecesDelayInSeconds(piecesDw));
                }
            }
        
            calculateMeanMaxMinOperDwAndLinkConsuption(ods, true);
            calculateMeanMaxMinDelay(delays, true);

            System.out.println(Constantes.logCreationRepeated);
            
            println(Constantes.logCreation, false);

            double UEsbyrrh = (countUEs+0.0) / Constantes.IDS_RRHs.size();
            double gigaByMEC = Utils.kiloToGiga(UEsbyrrh * Constantes.FILE_SIZE);
            println("UEs by RRH: " + Utils.TwoDec(UEsbyrrh) + " with approx. GB by MEC: " + Utils.TwoDec(gigaByMEC) + 
                    " (setting " + Constantes.STORAGE_MEC/(1000.0*1000.0) + " GB)", true);

            double attended = (seeders+0.0) / (countUEs+0.0);
            println("Seeders: " + seeders + " (" + countOthers + " others) of total: " + countUEs + " attended: " + Utils.TwoDec(attended) + " " + Constantes.choosenLatSpeed, true);
        }

        return false;
    }

    private void calculateMeanMaxMinDelay(List<Double[]> arr, boolean forExcel) {

        List<Double> dGeneral = new ArrayList<>();
        List<Double> dMyrrh_mec = new ArrayList<>();
        List<Double> dMyrrh_bbu = new ArrayList<>();
        List<Double> dOtherrrh = new ArrayList<>();

        for (Double[] d : arr) {
            if (d[0] != -1) dGeneral.add(d[0]);
            if (d[1] != -1 && !Double.isNaN(d[1])) dMyrrh_mec.add(d[1]);
            if (d[2] != -1 && !Double.isNaN(d[2])) dOtherrrh.add(d[2]);
            if (d[3] != -1 && !Double.isNaN(d[3])) dMyrrh_bbu.add(d[3]);
        }

        String strReport = "";

        DoubleSummaryStatistics dssG = dGeneral.stream().collect(Collectors.summarizingDouble(Double::doubleValue));
        DoubleSummaryStatistics dssMyMEC = dMyrrh_mec.stream().collect(Collectors.summarizingDouble(Double::doubleValue));
        DoubleSummaryStatistics dssOt = dOtherrrh.stream().collect(Collectors.summarizingDouble(Double::doubleValue));
        DoubleSummaryStatistics dssMyBBU = dMyrrh_bbu.stream().collect(Collectors.summarizingDouble(Double::doubleValue));

        if (forExcel) {
            strReport += "\nDelay MyRRH_BBU;" + Utils.TwoDec(dssMyBBU.getAverage()) + 
                        ";" + Utils.TwoDec(dssMyBBU.getMin()) + ";" + Utils.TwoDec(dssMyBBU.getMax());
            strReport += "\nDelay MyRRH_MEC;" + Utils.TwoDec(dssMyMEC.getAverage()) + 
                        ";" + Utils.TwoDec(dssMyMEC.getMin()) + ";" + Utils.TwoDec(dssMyMEC.getMax());
            strReport += "\nDelay OtRRH;" + Utils.TwoDec(dssOt.getAverage()) + 
                        ";" + Utils.TwoDec(dssOt.getMin()) + ";" + Utils.TwoDec(dssOt.getMax());
            strReport += "\nDelay Both;"+ Utils.TwoDec(dssG.getAverage()) + 
                        ";" + Utils.TwoDec(dssG.getMin()) + ";" + Utils.TwoDec(dssG.getMax());

        } else {
            strReport += "\n \t Delay General mean (" + dGeneral.size() + "): \t" + Utils.TwoDec(dssG.getAverage()) + 
                        " min: " + Utils.TwoDec(dssG.getMin()) + " max: " + Utils.TwoDec(dssG.getMax());
            strReport += "\n \t Delay MyRRH_MEC mean (" + dMyrrh_mec.size() + "): \t" + Utils.TwoDec(dssMyMEC.getAverage()) + 
                        " min: " + Utils.TwoDec(dssMyMEC.getMin()) + " max: " + Utils.TwoDec(dssMyMEC.getMax());
            strReport += "\n \t Delay OtRRH mean (" + dOtherrrh.size() + "): \t" + Utils.TwoDec(dssOt.getAverage()) + 
                        " min: " + Utils.TwoDec(dssOt.getMin()) + " max: " + Utils.TwoDec(dssOt.getMax());
            strReport += "\n \t Delay MyRRH_BBU mean (" + dMyrrh_bbu.size() + "): \t" + Utils.TwoDec(dssMyBBU.getAverage()) + 
                        " min: " + Utils.TwoDec(dssMyBBU.getMin()) + " max: " + Utils.TwoDec(dssMyBBU.getMax());
        }
        println(strReport, true);
    }
    
    private void calculateMeanMaxMinOperDwAndLinkConsuption(List<Double[]> ods, boolean forExcel) {
        
        List<Double> odGeneral = new ArrayList<>();
        List<Double> odMyrrhMEC = new ArrayList<>();
        List<Double> odOtherrrh = new ArrayList<>();
        List<Double> odMyrrhBBU = new ArrayList<>();
        for (Double[] od : ods) {
            if (od[0] != -1) odGeneral.add(od[0]);
            if (od[1] != -1 && !Double.isNaN(od[1])) odMyrrhMEC.add(od[1]);
            if (od[2] != -1 && !Double.isNaN(od[2])) odOtherrrh.add(od[2]);
            if (od[3] != -1 && !Double.isNaN(od[3])) odMyrrhBBU.add(od[3]);
        }

        String strReport = "";

        DoubleSummaryStatistics dssGeral = odGeneral.stream().collect(Collectors.summarizingDouble(Double::doubleValue));
        DoubleSummaryStatistics dssMyMEC = odMyrrhMEC.stream().collect(Collectors.summarizingDouble(Double::doubleValue));
        DoubleSummaryStatistics dssOther = odOtherrrh.stream().collect(Collectors.summarizingDouble(Double::doubleValue));
        DoubleSummaryStatistics dssMyBBU = odMyrrhBBU.stream().collect(Collectors.summarizingDouble(Double::doubleValue));

        if (forExcel) {
            strReport += "\nMbps MyRRH_BBU;" + Utils.TwoDec(dssMyBBU.getAverage()/1000.0) + 
                    ";" + Utils.TwoDec(dssMyBBU.getMin()/1000.0) + ";" + Utils.TwoDec(dssMyBBU.getMax()/1000.0);
            strReport += "\nMbps MyRRH_MEC;" + Utils.TwoDec(dssMyMEC.getAverage()/1000.0) + 
                    ";" + Utils.TwoDec(dssMyMEC.getMin()/1000.0) + ";" + Utils.TwoDec(dssMyMEC.getMax()/1000.0);
            strReport += "\nMbps OtRRH;" + Utils.TwoDec(dssOther.getAverage()/1000.0) + 
                    ";" + Utils.TwoDec(dssOther.getMin()/1000.0) + ";" + Utils.TwoDec(dssOther.getMax()/1000.0);
            strReport += "\nMbps Both;" + Utils.TwoDec(dssGeral.getAverage()/1000.0) + 
                    ";" + Utils.TwoDec(dssGeral.getMin()/1000.0) + ";" + Utils.TwoDec(dssGeral.getMax()/1000.0);
            
            
            strReport += "\nLink MyRRH_BBU;" + Utils.TwoDec(dssMyBBU.getAverage()/Constantes.CAPACITY_UE) + 
                    ";" + Utils.TwoDec(dssMyBBU.getMin()/Constantes.CAPACITY_UE) + ";" + Utils.TwoDec(dssMyBBU.getMax()/Constantes.CAPACITY_UE);
            strReport += "\nLink MyRRH_MEC;" + Utils.TwoDec(dssMyMEC.getAverage()/Constantes.CAPACITY_UE) + 
                    ";" + Utils.TwoDec(dssMyMEC.getMin()/Constantes.CAPACITY_UE) + ";" + Utils.TwoDec(dssMyMEC.getMax()/Constantes.CAPACITY_UE);
            strReport += "\nLink OtRRH;" + Utils.TwoDec(dssOther.getAverage()/Constantes.CAPACITY_UE) + 
                    ";" + Utils.TwoDec(dssOther.getMin()/Constantes.CAPACITY_UE) + ";" + Utils.TwoDec(dssOther.getMax()/Constantes.CAPACITY_UE);
            strReport += "\nLink Both;" + Utils.TwoDec(dssGeral.getAverage()/Constantes.CAPACITY_UE) + 
                    ";" + Utils.TwoDec(dssGeral.getMin()/Constantes.CAPACITY_UE) + ";" + Utils.TwoDec(dssGeral.getMax()/Constantes.CAPACITY_UE);
            
        } else {
            strReport += "\n \t Kbps General mean (" + odGeneral.size() + "): \t" + Utils.TwoDec(dssGeral.getAverage()) + 
                    " min: " + Utils.TwoDec(dssGeral.getMin()) + " max: " + Utils.TwoDec(dssGeral.getMax());
            strReport += "\n \t Kbps MyRRH_MEC mean (" + odMyrrhMEC.size() + "): \t" + Utils.TwoDec(dssMyMEC.getAverage()) + 
                    " min: " + Utils.TwoDec(dssMyMEC.getMin()) + " max: " + Utils.TwoDec(dssMyMEC.getMax());
            strReport += "\n \t Kbps OtherRRH mean (" + odOtherrrh.size() + "): \t" + Utils.TwoDec(dssOther.getAverage()) + 
                    " min: " + Utils.TwoDec(dssOther.getMin()) + " max: " + Utils.TwoDec(dssOther.getMax());
            
            strReport += "\n \t Link General mean (" + odGeneral.size() + "): \t" + Utils.TwoDec(dssGeral.getAverage()/Constantes.CAPACITY_UE) + 
                    " min: " + Utils.TwoDec(dssGeral.getMin()/Constantes.CAPACITY_UE) + " max: " + Utils.TwoDec(dssGeral.getMax()/Constantes.CAPACITY_UE);
            strReport += "\n \t Link MyRRH_MEC mean (" + odMyrrhMEC.size() + "): \t" + Utils.TwoDec(dssMyMEC.getAverage()/Constantes.CAPACITY_UE) + 
                    " min: " + Utils.TwoDec(dssMyMEC.getMin()/Constantes.CAPACITY_UE) + " max: " + Utils.TwoDec(dssMyMEC.getMax()/Constantes.CAPACITY_UE);
            strReport += "\n \t Link OtherRRH mean (" + odOtherrrh.size() + "): \t" + Utils.TwoDec(dssOther.getAverage()/Constantes.CAPACITY_UE) + 
            " min: " + Utils.TwoDec(dssOther.getMin()/Constantes.CAPACITY_UE) + " max: " + Utils.TwoDec(dssOther.getMax()/Constantes.CAPACITY_UE);
        }
        println(strReport, true);
    }

    private void println(String str, boolean print) {
        if(print) System.out.println("[ControlReport] " + str + " -- " + CommonState.getTime());
    }
}
